function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% You need to return the following variables correctly 
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

% ====================== YOUR CODE HERE ======================
% Instructions: You should complete the code by working through the
%               following parts.
%
% Part 1: Feedforward the neural network and return the cost in the
%         variable J. After implementing Part 1, you can verify that your
%         cost function computation is correct by verifying the cost
%         computed in ex4.m

X = [ones(m, 1) X]; % Add ones to the X data matrix (adding bias unit to first layer)

%calculate the predictions (feedforward)
a1 = X;

z2 = a1 * Theta1';
a2 = sigmoid(z2);
a2 = [ones(m, 1), a2];    % add bias unit to second layer

z3 = a2 * Theta2';
a3 = sigmoid(z3);

predictions = a3;

% calculate cost for the predictions (theta / weights)
for i = 1:m
    encoded_y = zeros(num_labels, 1);
    encoded_y(y(i)) = 1;
    J = J + sum(-encoded_y' .* log(predictions(i, :)) - (1 - encoded_y') .* log(1 - predictions(i, :)));
end
J = J * (1/m);

% regularize the cost (dont regularize the bias term (first column of Theta1 and Theta2))
reg = 0;

for j = 1:size(Theta1, 1)
    for k = 2:size(Theta1, 2)
        reg = reg + Theta1(j,k) * Theta1(j,k);
    end
end

for j = 1:size(Theta2, 1)
    for k = 2:size(Theta2, 2)
        reg = reg + Theta2(j,k) * Theta2(j,k);
    end
end
             
reg = (lambda / (2*m)) * reg;
J = J+reg;


%
% Part 2: Implement the backpropagation algorithm to compute the gradients
%         Theta1_grad and Theta2_grad. You should return the partial derivatives of
%         the cost function with respect to Theta1 and Theta2 in Theta1_grad and
%         Theta2_grad, respectively. After implementing Part 2, you can check
%         that your implementation is correct by running checkNNGradients
%
%         Note: The vector y passed into the function is a vector of labels
%               containing values from 1..K. You need to map this vector into a 
%               binary vector of 1's and 0's to be used with the neural network
%               cost function.
%
%         Hint: We recommend implementing backpropagation using a for-loop
%               over the training examples if you are implementing it for the 
%               first time.

DELTA1 = zeros(hidden_layer_size, input_layer_size+1);
DELTA2 = zeros(num_labels, hidden_layer_size+1);

for t = 1:m
    % step 1
    a1 = X(t, 1:end);   % X already contains bias unit for layer 1
    
    z2 = a1 * Theta1';
    a2 = sigmoid(z2);
    a2 = [1, a2];      % add bias unit to second layer
    
    z3 = a2 * Theta2';
    a3 = sigmoid(z3);
    
    predictions = a3;
    
    %step 2
    encoded_y = zeros(num_labels, 1);
    encoded_y(y(t)) = 1;
    delta3 = predictions - encoded_y';
    
    %step 3
    z2temp = [1, z2]; %hack(?)
    delta2 = Theta2' * delta3' .* sigmoidGradient(z2temp)';
    
    %step 4
    delta2 = delta2(2:end); %remove delta_0^2
    DELTA1 = DELTA1 + (delta2 * a1);
    DELTA2 = DELTA2 + (delta3' * a2);     
end

% step 5
Theta1_grad = (1/m) * DELTA1;
Theta2_grad = (1/m) * DELTA2;
%
% Part 3: Implement regularization with the cost function and gradients.
%
%         Hint: You can implement this around the code for
%               backpropagation. That is, you can compute the gradients for
%               the regularization separately and then add them to Theta1_grad
%               and Theta2_grad from Part 2.
%

temp = Theta1;
temp(:,1) = 0;
Theta1_grad = Theta1_grad + (lambda/m) * temp;

temp = Theta2;
temp(:,1) = 0;
Theta2_grad = Theta2_grad + (lambda/m) * temp;
















% -------------------------------------------------------------

% =========================================================================

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];


end
